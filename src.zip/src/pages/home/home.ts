import { ProddetailsPage } from './../proddetails/proddetails';
import { Component } from '@angular/core';
import { NavController,MenuController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public menuCtrl:MenuController,public navCtrl: NavController) {

  }

  goDetails(){
    this.navCtrl.push(ProddetailsPage);
  }
  toggleMenu()
  {
      this.menuCtrl.toggle();
  }
}
